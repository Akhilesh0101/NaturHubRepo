﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;
using WebAPINatureHub3.ProductDtos;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly NatureHub3Context _context;

        public ProductController(NatureHub3Context context)
        {
            _context = context;
        }

        // POST: api/Product
        [HttpPost]
       
        public async Task<IActionResult> CreateProduct([FromForm] CreateProductDTO createProductDTO, IFormFile file)
        {
            // Validate fields
            if (file == null || file.Length == 0)
            {
                return BadRequest("No image provided.");
            }
            if (string.IsNullOrWhiteSpace(createProductDTO.ProductName))
                return BadRequest("Product name is required.");
            if (createProductDTO.Price <= 0)
                return BadRequest("Price must be greater than zero.");
            if (createProductDTO.StockQuantity < 0)
                return BadRequest("Stock quantity cannot be negative.");

            // Convert file to byte array
            byte[] fileData;
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                fileData = memoryStream.ToArray();
            }

            // Create the product and save to database
            var product = new Product
            {
                ProductName = createProductDTO.ProductName,
                Productimg = fileData,  // Store the image as byte array
                Price = createProductDTO.Price,
                Description = createProductDTO.Description,
                StockQuantity = createProductDTO.StockQuantity,
                CategoryId = createProductDTO.CategoryId
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            // Return the created product in the ReadProductDTO format
            var productDTO = new ReadProductDTO
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductImage = product.Productimg,
                Price = product.Price,
                Description = product.Description,
                StockQuantity = (int)product.StockQuantity,
                CategoryId = product.CategoryId
            };

            return CreatedAtAction(nameof(GetProduct), new { id = product.ProductId }, productDTO);
        }

        // GET: api/Product/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound("Product not found.");
            }

            var productDTO = new ReadProductDTO
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductImage = product.Productimg,
                Price = product.Price,
                Description = product.Description,
                StockQuantity = (int)product.StockQuantity,
                CategoryId = product.CategoryId
            };

            return Ok(productDTO);
        }

        // PUT: api/Product/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromForm] UpdateProductDTO updateProductDTO, IFormFile? file)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound("Product not found.");
            }

            // Update product data from DTO
            product.ProductName = updateProductDTO.ProductName;
            product.Price = updateProductDTO.Price;
            product.Description = updateProductDTO.Description;
            product.StockQuantity = updateProductDTO.StockQuantity;
            product.CategoryId = updateProductDTO.CategoryId;

            // If a new image is uploaded, update it
            if (file != null && file.Length > 0)
            {
                byte[] fileData;
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    fileData = memoryStream.ToArray();
                }
                product.Productimg = fileData;  // Update product image
            }

            await _context.SaveChangesAsync();
            return Ok(new { Message = "Product updated successfully." });
        }

        // DELETE: api/Product/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound("Product not found.");
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Product deleted successfully." });
        }

        // GET: api/Product
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _context.Products.ToListAsync();
            if (products == null || !products.Any())
            {
                return NotFound("No products found.");
            }

            var productDTOs = products.Select(product => new ReadProductDTO
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductImage = product.Productimg,
                Price = product.Price,
                Description = product.Description,
                StockQuantity = (int)product.StockQuantity,
                CategoryId = product.CategoryId
            }).ToList();

            return Ok(productDTOs);
        }
    }
}
