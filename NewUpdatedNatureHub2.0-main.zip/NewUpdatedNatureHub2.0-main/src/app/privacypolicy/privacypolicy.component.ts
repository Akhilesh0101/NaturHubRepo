import { Component } from '@angular/core';

@Component({
  selector: 'app-privacypolicy',
  standalone: false,
  
  templateUrl: './privacypolicy.component.html',
  styleUrl: './privacypolicy.component.css'
})
export class PrivacypolicyComponent {

}
