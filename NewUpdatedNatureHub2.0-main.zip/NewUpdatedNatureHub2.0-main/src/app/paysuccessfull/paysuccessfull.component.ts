import { Component } from '@angular/core';

@Component({
  selector: 'app-paysuccessfull',
  standalone: false,
  
  templateUrl: './paysuccessfull.component.html',
  styleUrl: './paysuccessfull.component.css'
})
export class PaysuccessfullComponent {

}
