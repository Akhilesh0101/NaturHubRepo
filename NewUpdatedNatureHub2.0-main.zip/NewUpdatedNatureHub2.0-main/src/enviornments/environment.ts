export const environment = {
    production: false,
    apiUrl: 'https://localhost:44348' // Update with your backend URL
  };